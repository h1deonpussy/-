import socket
import threading
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding

class TCPCommunication:
    def __init__(self, aes_key=None):
        self.sock = None
        self.conn = None
        self.is_connected = False
        self.lock = threading.Lock()
        # AES加密配置（默认256位，与web_server一致）
        self.aes_key = aes_key or b'secure_aes_key_32bytes!'  # 32字节=256位
        self.iv = b'16byte_iv_vector!'  # 16字节IV（固定用于演示，实际应动态生成）

    # 连接服务器
    def connect_server(self, host, port):
        with self.lock:
            try:
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.connect((host, port))
                self.is_connected = True
                return True
            except Exception as e:
                print(f"连接失败: {e}")
                return False

    # 启动服务器
    def start_server(self, host, port):
        with self.lock:
            try:
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.sock.bind((host, port))
                self.sock.listen(5)
                return True
            except Exception as e:
                print(f"启动服务器失败: {e}")
                return False

    # 接受客户端连接
    def accept(self):
        try:
            conn, addr = self.sock.accept()
            client_comm = TCPCommunication(self.aes_key)
            client_comm.conn = conn
            client_comm.is_connected = True
            return client_comm, addr
        except Exception as e:
            print(f"接受连接失败: {e}")
            return None, None

    # AES加密（适配文本/文件数据）
    def aes_encrypt(self, data):
        try:
            cipher = Cipher(algorithms.AES(self.aes_key), modes.CBC(self.iv), backend=default_backend())
            encryptor = cipher.encryptor()
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(data) + padder.finalize()
            return encryptor.update(padded_data) + encryptor.finalize()
        except Exception as e:
            print(f"AES加密失败: {e}")
            return b""

    # AES解密
    def aes_decrypt(self, data):
        try:
            cipher = Cipher(algorithms.AES(self.aes_key), modes.CBC(self.iv), backend=default_backend())
            decryptor = cipher.decryptor()
            unpadder = padding.PKCS7(128).unpadder()
            decrypted = decryptor.update(data) + decryptor.finalize()
            return unpadder.update(decrypted) + unpadder.finalize()
        except Exception as e:
            print(f"AES解密失败: {e}")
            return b""

    # 发送加密数据
    def send_data(self, data):
        with self.lock:
            if not self.is_connected:
                return False
            try:
                encrypted_data = self.aes_encrypt(data)
                target_sock = self.conn if self.conn else self.sock
                target_sock.sendall(encrypted_data)
                return True
            except Exception as e:
                print(f"发送失败: {e}")
                self.is_connected = False
                return False

    # 接收解密数据
    def recv_data(self, bufsize=4096):
        with self.lock:
            if not self.is_connected:
                return None
            try:
                target_sock = self.conn if self.conn else self.sock
                encrypted_data = target_sock.recv(bufsize)
                if not encrypted_data:
                    self.is_connected = False
                    return None
                return self.aes_decrypt(encrypted_data)
            except Exception as e:
                print(f"接收失败: {e}")
                self.is_connected = False
                return None

    # 关闭连接
    def close(self):
        with self.lock:
            self.is_connected = False
            if self.conn:
                self.conn.close()
            if self.sock:
                self.sock.close()